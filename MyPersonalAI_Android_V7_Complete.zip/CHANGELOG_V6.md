# V6 — কী পরিবর্তন হলো (V5 থেকে)

সততার সাথে বলছি: এটা "নতুন feature-এর বিশাল তালিকা" না। এটা V5-কে বাস্তবে
কাজ করার মতো করে তোলা এবং interface সুন্দর করার upgrade। প্রতিটা পরিবর্তন
নিচে স্পষ্টভাবে লেখা আছে, যাতে বুঝতে পারেন ঠিক কী বদলেছে।

## 🐛 গুরুত্বপূর্ণ বাগ ফিক্স

1. **Release APK-তে internet কাজ করত না** — Android শুধু debug build-এ
   automatic INTERNET permission দেয়; release build-এ (যেটা আপনি আসলে
   ফোনে install করবেন) সেটা দেয় না। V5-এর manifest-patch script এটা
   explicitly যোগ করত না, ফলে চ্যাট, upload, health-check — সবকিছুই
   release APK-তে silently fail করত, যদিও `flutter run`-এ ঠিকঠাক কাজ
   করত। এখন `PATCH_ANDROID_MANIFEST.ps1` explicitly INTERNET permission
   যোগ করে।

2. **App-এ যে ৩টা backend feature call হতো, সেগুলোর backend endpoint-ই
   ছিল না** — "New chat" (`/sessions`), "Notes" (`/notes`), "Audit log"
   (`/audit`) — app এই route-গুলো call করত কিন্তু `backend/main.py`-তে
   সেগুলো কখনো লেখাই হয়নি। তাই এই তিনটা button আগে চাপলে backend থেকে
   404 error আসত (app-এ সেটা চুপচাপ snackbar-এ দেখাত)। এখন backend-এ
   সেশন, নোট (create/edit/delete) এবং audit-log endpoint বাস্তবে যোগ
   করা হয়েছে, এবং প্রতিটা ingest/delete/chat/note action audit log-এ
   record হয়।

## 🎨 Interface আপগ্রেড

- নতুন brand color scheme (indigo/blue + teal accent), Material 3
- চ্যাট বাবল এখন real messaging app-এর মতো — user/AI আলাদা রঙ, avatar,
  rounded corner, ডান/বাঁয়ে align
- Backend online/offline status এখন একটা tappable pill/chip আকারে,
  refresh করা যায় এক ট্যাপে
- Source Library-তে ফাইল টাইপ অনুযায়ী আলাদা icon (PDF/Image/Video/DOCX/
  CSV/JSON), ফাইলের size দেখানো হয়
- Empty states (কোনো source/note/audit-event না থাকলে) এখন বোঝার মতো
  message ও icon দেখায়, খালি সাদা স্ক্রিন নয়
- Source delete করার আগে এখন confirm dialog আসে ("মুছে ফেলবেন?")
- Notes sheet-এ এখন সত্যিকারের "+ New" button আছে — আগে শুধু existing
  note edit করা যেত, নতুন note তৈরি করার কোনো উপায়ই ছিল না
- Chat header এখন gradient card, lock/unlock ভিজ্যুয়ালি স্পষ্ট

## ❌ যা এখনও সম্ভব নয় (honestly)

- Compiled `.apk` — এই সীমাবদ্ধতা অপরিবর্তিত। এই source package
  Windows PC-তে Flutter/Android SDK দিয়ে build করতে হবে।
- Human-like cloud voice, real image/music generation, video
  transcription — এগুলো এখনও specific provider adapter-এর উপর নির্ভরশীল
  এবং ইচ্ছাকৃতভাবে fake করা হয়নি।
