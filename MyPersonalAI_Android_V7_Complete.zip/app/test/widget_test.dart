// The default file `flutter create` generates here expects a widget class
// called MyApp (from the counter-app template) and would fail to compile,
// since our root widget is MyPersonalAI. The build scripts run
// `flutter test` before building the APK, so a broken test file would
// block every build. This file replaces it with a minimal sanity check
// so the release build pipeline never gets stuck on template leftovers.

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('project sanity check', () {
    expect(1 + 1, 2);
  });
}
