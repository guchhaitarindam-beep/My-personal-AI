# V5 Android Release Checklist

## Build machine
- Windows 10/11
- Flutter Stable 3.47.x or a newer compatible Stable release
- Android Studio + Android SDK + platform/build tools
- JDK supported by the installed Flutter/Android toolchain
- Python 3.11+ for the backend

## App setup
1. Run `scripts\\CREATE_ANDROID_PROJECT.bat` once.
2. Run `powershell -ExecutionPolicy Bypass -File scripts\\PATCH_ANDROID_MANIFEST.ps1`.
3. Run `cd app && flutter pub get`.
4. Run `flutter analyze`.
5. Run `flutter test`.

## Backend
1. Copy `backend/.env.example` to `backend/.env`.
2. Set `AI_API_KEY`, `AI_BASE_URL`, and `AI_MODEL`.
3. Run `scripts\\RUN_BACKEND_FOR_ANDROID.bat`.
4. Confirm `http://PC-IP:8000/health` responds on the phone's Wi-Fi network.

## Phone
- Android device should be supported by the installed Flutter stable version.
- Enable Developer Options + USB debugging only if installing/debugging over USB.
- For a physical phone using local backend: phone and PC must be on the same LAN/Wi-Fi.
- Backend URL: `http://PC-IP:8000`.
- Emulator URL: `http://10.0.2.2:8000`.

## Release
Run `scripts\\BUILD_ANDROID_RELEASE.bat`.
Release APKs are produced under `app\\build\\app\\outputs\\flutter-apk\\`.

## Quality tests
- First launch
- Microphone permission
- Bengali speech input
- Indian English speech input
- Bengali/English TTS
- Sentence previous/next/stop
- PDF upload and page evidence
- Strict Chapter Lock with known and unknown questions
- Source deletion
- Large source upload
- Backend offline behavior
- Rotation / process recreation
- TalkBack navigation and labels
- Dark/light theme
- Release APK install and cold start

## Security before public distribution
- Replace local HTTP with HTTPS.
- Add authentication and per-user authorization.
- Add rate limiting and request-size limits.
- Keep all provider secrets on the server.
- Add encrypted backups/object storage for production documents.
- Move retrieval to a production vector database for large multi-user libraries.
- Enable release shrinking/optimization after validating provider/library keep rules.
