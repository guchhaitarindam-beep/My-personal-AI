# Architecture

Flutter UI → FastAPI → Provider Gateway
                    ├─ Chat (OpenAI-compatible)
                    ├─ Strict Source Retriever
                    ├─ PDF/DOCX/Text extraction
                    ├─ OCR adapter
                    ├─ Video/FFmpeg hook
                    ├─ TTS adapter hook
                    └─ Image/Music adapter hooks

Storage:
- data/index.json: persistent source metadata + chunks
- data/sources/: uploaded originals

Strict mode is evidence-first. The backend does not dump an entire large book into a prompt. It retrieves a small set of relevant chunks, preserving page numbers when available.

Production scaling path:
1. Move index/chunks to PostgreSQL + pgvector/Qdrant.
2. Add embeddings retrieval alongside lexical retrieval.
3. Add authenticated users and encrypted storage.
4. Add background jobs for OCR/transcription.
5. Add provider adapters with typed response schemas.
6. Add automated integration tests and CI.
