# MY PERSONAL AI V7 — ANDROID EDITION

এটি V5-এর upgrade — UI redesign, missing backend endpoint ফিক্স এবং একটি গুরুত্বপূর্ণ release-build networking বাগ ফিক্স করা হয়েছে। Android APK build-এর জন্য Flutter Stable + Android Studio/SDK প্রয়োজন। Flutter-এর বর্তমান deployment documentation Android build/release workflow দেয়, এবং Flutter 3.47.2 বর্তমানে Android API 24–37-এর deployment support দেখায়।

> 📱 **ফোন দিয়ে APK build করতে চান (PC ছাড়া)?** দেখুন `BUILD_FROM_PHONE_BN.md`।
> নতুন কী যোগ হলো তার বিস্তারিত: `CHANGELOG_V7.md`।

## কী আছে
- Android-only Flutter project workflow
- Bengali India / Indian English voice
- Speech input
- Strict Chapter Lock + source evidence
- Persistent source library
- PDF/DOCX/TXT/CSV/JSON + image/video upload hooks
- Study engine
- Creative Studio
- Accessibility labels + large controls
- Backend health indicator
- Physical phone বনাম emulator-এর জন্য backend URL আলাদা করে সেট করার ব্যবস্থা

## গুরুত্বপূর্ণ architecture
অ্যাপটি নিজে AI model চালাচ্ছে না। নিরাপদ architecture হলো:
Android app → HTTPS/LAN backend → AI provider / document engine / OCR / transcription / generation provider

API key APK-এর ভিতরে রাখা উচিত নয়। Backend-এ রাখুন।

## Android-এ চালানোর ধাপ
1. Windows PC-তে Flutter Stable এবং Android Studio/SDK install করুন।
2. এই package extract করুন।
3. `scripts\CREATE_ANDROID_PROJECT.bat` চালান।
4. `scripts\PATCH_ANDROID_MANIFEST.ps1` চালান।
5. `app` folder-এ `flutter pub get` চালান।
6. Backend-এর `.env` তৈরি করে AI provider credentials দিন।
7. `scripts\RUN_BACKEND_FOR_ANDROID.bat` চালান।
8. Android ফোন ও PC একই Wi‑Fi-তে রাখুন।
9. অ্যাপে Settings → Backend URL → `http://PC-LAN-IP:8000` দিন। উদাহরণ: `http://192.168.1.10:8000`।
10. `scripts\BUILD_ANDROID_RELEASE.bat` চালান।
11. `app\build\app\outputs\flutter-apk\`-এর APK ফোনে install করুন।

## Emulator
Android emulator থেকে PC backend সাধারণত `http://10.0.2.2:8000` দিয়ে পৌঁছায়।

## Physical phone
ফোনে `10.0.2.2` ব্যবহার করবেন না। Windows PC-এর IPv4 LAN address ব্যবহার করুন। Windows Firewall-এ TCP 8000 inbound access প্রয়োজন হতে পারে।

## Permissions
- INTERNET: backend/AI service communication
- RECORD_AUDIO: voice input
- File picker ব্যবহারের কারণে broad storage permission না নিয়ে Android-এর scoped picker ব্যবহার করাই ভালো।

## Release quality
Build-এর আগে `flutter analyze` এবং `flutter test` চালানো হয়। এরপর release APK তৈরি হয়। বাস্তব ফোনে TalkBack, Bengali speech, microphone permission, upload, network failure এবং large PDF পরীক্ষা করা আবশ্যক।

## কী এখনও provider-dependent
- Premium natural cloud voice
- Real image generation
- Real music generation
- OCR for scanned images/PDFs
- Video transcription/vision
- Live web agent
এসবের জন্য provider adapter/backend integration লাগবে; APK নিজে এগুলো তৈরি করতে পারে না।
