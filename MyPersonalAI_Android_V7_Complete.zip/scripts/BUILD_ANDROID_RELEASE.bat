@echo off
setlocal
cd /d "%~dp0..\app"
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter was not found in PATH.
  echo Install Flutter Stable and Android Studio/SDK first.
  exit /b 1
)
flutter pub get
if errorlevel 1 exit /b 1
flutter analyze
if errorlevel 1 exit /b 1
flutter test
if errorlevel 1 exit /b 1
flutter build apk --release --split-per-abi
if errorlevel 1 exit /b 1
echo.
echo BUILD COMPLETE.
echo APKs are in app\build\app\outputs\flutter-apk\
dir /b build\app\outputs\flutter-apk\
endlocal
