"""Patches AndroidManifest.xml with the permissions this app needs.

Cross-platform equivalent of scripts/PATCH_ANDROID_MANIFEST.ps1, used by
the GitHub Actions cloud-build workflow (Linux runners can't run
PowerShell .ps1 scripts). Safe to run more than once -- it only adds a
permission if it is not already present.

Usage: python3 scripts/patch_manifest.py [path-to-project-root]
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
manifest = root / "app" / "android" / "app" / "src" / "main" / "AndroidManifest.xml"

if not manifest.exists():
    print(f"AndroidManifest.xml not found at {manifest}. Run the Android project-create step first.")
    sys.exit(1)

text = manifest.read_text(encoding="utf-8")

permissions = [
    "android.permission.INTERNET",  # NOT auto-added for release builds -- required for chat/upload/health-check.
    "android.permission.RECORD_AUDIO",  # voice input
    "android.permission.VIBRATE",  # haptic feedback on voice-mode toggle
]

for perm in permissions:
    if perm not in text:
        text = re.sub(r"(<manifest[^>]*>)", rf'\1\n    <uses-permission android:name="{perm}" />', text, count=1)
        print(f"Added permission: {perm}")
    else:
        print(f"Already present: {perm}")

if "android:usesCleartextTraffic" not in text:
    text = re.sub(r"(<application[^>]*)>", r'\1 android:usesCleartextTraffic="true">', text, count=1)
    print("Enabled usesCleartextTraffic (local HTTP development only -- use HTTPS in production).")
else:
    print("usesCleartextTraffic already set.")

manifest.write_text(text, encoding="utf-8")
print("AndroidManifest.xml patched.")
