@echo off
setlocal
cd /d "%~dp0..\backend"
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found in PATH.
  exit /b 1
)
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 exit /b 1
python -m uvicorn main:app --host 0.0.0.0 --port 8000
endlocal
