@echo off
setlocal
where flutter >nul 2>nul || (echo Flutter Stable not found in PATH. Install Flutter first.& exit /b 1)
if not exist app\pubspec.yaml (echo Run this from the V5 package root.& exit /b 1)
if exist app\android (echo Android project already exists.& exit /b 0)
cd app
flutter create . --platforms=android --project-name=my_personal_ai
if errorlevel 1 exit /b 1
cd ..
rem flutter create's default test/widget_test.dart references a "MyApp" class
rem that doesn't exist in this project and would break `flutter test`. Force
rem our own minimal test back into place no matter what was just generated.
powershell -NoProfile -Command "Set-Content -Encoding UTF8 -Path 'app\test\widget_test.dart' -Value \"import 'package:flutter_test/flutter_test.dart';`n`nvoid main() {`n  test('project sanity check', () {`n    expect(1 + 1, 2);`n  });`n}`n\""
echo Android project skeleton created successfully.
echo Next: run scripts\PATCH_ANDROID_MANIFEST.ps1, then scripts\BUILD_ANDROID_RELEASE.bat
