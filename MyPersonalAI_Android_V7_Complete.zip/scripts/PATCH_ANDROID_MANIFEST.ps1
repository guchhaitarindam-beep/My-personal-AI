$manifest = Join-Path $PSScriptRoot '..\app\android\app\src\main\AndroidManifest.xml'
if (!(Test-Path $manifest)) { Write-Host 'Android project not created yet. Run CREATE_ANDROID_PROJECT.bat first.'; exit 1 }
$text = Get-Content $manifest -Raw

# IMPORTANT: Flutter/Android only auto-merges the INTERNET permission for DEBUG builds
# (via a debug-only manifest). A --release APK does NOT get it automatically, so without
# this explicit line every network call (chat, upload, health check) silently fails only
# in the release build while working fine during `flutter run`.
if ($text -notmatch 'android.permission.INTERNET') {
  $text = $text -replace '<manifest([^>]*)>', '<manifest$1>`n    <uses-permission android:name="android.permission.INTERNET" />', 1
}
if ($text -notmatch 'android.permission.RECORD_AUDIO') {
  $text = $text -replace '<manifest([^>]*)>', '<manifest$1>`n    <uses-permission android:name="android.permission.RECORD_AUDIO" />', 1
}
if ($text -notmatch 'android.permission.VIBRATE') {
  $text = $text -replace '<manifest([^>]*)>', '<manifest$1>`n    <uses-permission android:name="android.permission.VIBRATE" />', 1
}
if ($text -notmatch 'android:usesCleartextTraffic') {
  $text = $text -replace '<application([^>]*)>', '<application$1 android:usesCleartextTraffic="true">', 1
}
Set-Content $manifest $text -Encoding UTF8
Write-Host 'Android manifest patched: INTERNET + RECORD_AUDIO permissions added, local-development HTTP allowed.'
Write-Host 'IMPORTANT: usesCleartextTraffic=true is for local HTTP development only. Use HTTPS in production.'
