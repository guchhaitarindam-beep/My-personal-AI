from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, Response, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None
try:
    from docx import Document
except Exception:
    Document = None
try:
    from PIL import Image
    import pytesseract
except Exception:
    Image = None
    pytesseract = None

load_dotenv()
APP_VERSION = "6.0.0"
DATA_DIR = Path(os.getenv("DATA_DIR", "./data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
SOURCES_DIR = DATA_DIR / "sources"
SOURCES_DIR.mkdir(exist_ok=True)
INDEX_FILE = DATA_DIR / "index.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"
NOTES_FILE = DATA_DIR / "notes.json"
AUDIT_FILE = DATA_DIR / "audit.json"

app = FastAPI(title="My Personal AI", version=APP_VERSION)
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins or ["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])


def _load_json(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return default


def _save_json(path: Path, data: dict[str, Any]) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def load_index() -> dict[str, Any]:
    return _load_json(INDEX_FILE, {"sources": {}})

INDEX = load_index()
SESSIONS = _load_json(SESSIONS_FILE, {"sessions": {}})
NOTES = _load_json(NOTES_FILE, {"notes": {}})
AUDIT = _load_json(AUDIT_FILE, {"events": []})


def save_index() -> None:
    _save_json(INDEX_FILE, INDEX)


def save_sessions() -> None:
    _save_json(SESSIONS_FILE, SESSIONS)


def save_notes() -> None:
    _save_json(NOTES_FILE, NOTES)


def save_audit() -> None:
    _save_json(AUDIT_FILE, AUDIT)


def new_id() -> str:
    return hashlib.sha256(os.urandom(16)).hexdigest()[:16]


def now_ts() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def log_event(event: str, detail: str = "") -> None:
    AUDIT["events"].append({"event": event, "detail": detail, "ts": now_ts()})
    AUDIT["events"] = AUDIT["events"][-500:]
    save_audit()


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def tokens(text: str) -> list[str]:
    return [x for x in re.findall(r"[\w\u0980-\u09FF]+", (text or "").lower()) if len(x) > 1]


def sid_for(name: str, content: bytes) -> str:
    return hashlib.sha256(name.encode() + content).hexdigest()[:24]


def chunk_text(text: str, page: int | None = None, chunk_size: int = 1100, overlap: int = 180) -> list[dict[str, Any]]:
    text = clean(text)
    if not text:
        return []
    out = []
    start = 0
    while start < len(text):
        end = min(len(text), start + chunk_size)
        if end < len(text):
            cut = text.rfind(" ", start, end)
            if cut > start + 500:
                end = cut
        piece = text[start:end].strip()
        if piece:
            out.append({"text": piece, "page": page})
        if end >= len(text):
            break
        start = max(start + 1, end - overlap)
    return out


def extract_file(path: Path, suffix: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    suffix = suffix.lower()
    chunks: list[dict[str, Any]] = []
    meta: dict[str, Any] = {"extraction": "none"}
    if suffix == ".pdf" and PdfReader:
        reader = PdfReader(str(path))
        for page_no, page in enumerate(reader.pages, 1):
            text = clean(page.extract_text() or "")
            chunks.extend(chunk_text(text, page=page_no))
        meta = {"extraction": "pdf_text", "pages": len(reader.pages)}
    elif suffix == ".docx" and Document:
        doc = Document(str(path))
        text = "\n".join(p.text for p in doc.paragraphs)
        chunks = chunk_text(text)
        meta = {"extraction": "docx_text"}
    elif suffix in {".txt", ".md", ".csv", ".json"}:
        text = path.read_text(encoding="utf-8", errors="ignore")
        chunks = chunk_text(text)
        meta = {"extraction": "plain_text"}
    elif suffix in {".png", ".jpg", ".jpeg", ".webp", ".bmp"} and Image and pytesseract:
        try:
            text = pytesseract.image_to_string(Image.open(path), lang=os.getenv("OCR_LANG", "eng"))
            chunks = chunk_text(text)
            meta = {"extraction": "ocr"}
        except Exception as exc:
            meta = {"extraction": "ocr_failed", "error": str(exc)}
    elif suffix in {".mp4", ".mov", ".mkv", ".webm", ".avi"}:
        # Optional local extraction: if ffmpeg is available, extract an audio track.
        ffmpeg = shutil.which("ffmpeg")
        if ffmpeg:
            wav = path.with_suffix(".wav")
            try:
                subprocess.run([ffmpeg, "-y", "-i", str(path), "-vn", "-ac", "1", "-ar", "16000", str(wav)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=300)
                meta = {"extraction": "video_audio_extracted", "audio_path": str(wav)}
            except Exception as exc:
                meta = {"extraction": "video_audio_failed", "error": str(exc)}
        else:
            meta = {"extraction": "video_stored", "note": "Install ffmpeg plus a transcription adapter for transcript indexing."}
    return chunks, meta


def source_payload(sid: str) -> dict[str, Any] | None:
    return INDEX.get("sources", {}).get(sid)


def retrieve(source: dict[str, Any], query: str, k: int = 8) -> list[dict[str, Any]]:
    q = set(tokens(query))
    scored = []
    for c in source.get("chunks", []):
        ct = set(tokens(c.get("text", "")))
        if not ct:
            continue
        overlap = len(q & ct)
        if overlap == 0:
            continue
        score = overlap / math.sqrt(max(1, len(q) * len(ct)))
        # Exact phrase bonus.
        if query.lower().strip() in c.get("text", "").lower():
            score += 0.25
        scored.append((score, c))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [c for _, c in scored[:k]]


def strict_prompt(source: dict[str, Any], evidence: list[dict[str, Any]], question: str) -> str:
    blocks = []
    for i, c in enumerate(evidence, 1):
        loc = f"page {c['page']}" if c.get("page") else "source"
        blocks.append(f"[EVIDENCE {i} | {loc}] {c['text']}")
    evidence_text = "\n\n".join(blocks) or "NO_RELEVANT_EVIDENCE"
    return f"""You are a strict private-source study assistant.
RULES:
1. Answer ONLY from the evidence below. Do not use general knowledge, web knowledge, memory, or assumptions.
2. If the evidence does not contain enough information, reply exactly: এই তথ্যটি নির্বাচিত source-এ পাওয়া যায়নি।
3. Never invent page numbers or quotations.
4. Keep the answer clear and appropriate for the student's level.
5. If evidence supports the answer, append a compact source note such as (পৃষ্ঠা 4) when a page is available.

SELECTED SOURCE: {source.get('name','unknown')}
QUESTION: {question}

EVIDENCE:
{evidence_text}
"""


def general_prompt() -> str:
    return "You are a capable personal AI assistant. Support Bengali and Indian English. Be accurate, transparent about uncertainty, and concise unless detail is requested."


def web_prompt() -> str:
    return "You are a web-research assistant. Do not claim to browse unless web evidence is actually supplied by a connected web agent."


class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=20000)
    mode: str = Field(default="general")
    source_id: str | None = None
    session_id: str | None = None


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=20000)
    kind: str = Field(default="image")


class TtsRequest(BaseModel):
    text: str = Field(min_length=1, max_length=5000)
    lang: str = Field(default="bn")  # "bn" or "en"


class SessionRequest(BaseModel):
    title: str = Field(default="New chat", max_length=200)


class NoteRequest(BaseModel):
    title: str = Field(default="", max_length=200)
    body: str = Field(default="", max_length=20000)


async def chat_provider(system: str, question: str) -> str:
    key = os.getenv("AI_API_KEY", "").strip()
    base = os.getenv("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = os.getenv("AI_MODEL", "").strip()
    if not key or not model:
        return "AI provider is not configured. Set AI_API_KEY, AI_BASE_URL and AI_MODEL in backend/.env."
    payload = {"model": model, "messages": [{"role": "system", "content": system}, {"role": "user", "content": question}], "temperature": 0.2}
    async with httpx.AsyncClient(timeout=180) as client:
        r = await client.post(f"{base}/chat/completions", headers={"Authorization": f"Bearer {key}"}, json=payload)
        r.raise_for_status()
        data = r.json()
    return data["choices"][0]["message"]["content"].strip()


@app.get("/health")
def health() -> dict[str, Any]:
    return {"ok": True, "service": "my-personal-ai", "version": APP_VERSION}


@app.get("/sources")
def list_sources() -> dict[str, Any]:
    return {"sources": [{"id": s["id"], "name": s["name"], "type": s.get("type"), "chunks": len(s.get("chunks", [])), "meta": s.get("meta", {})} for s in INDEX.get("sources", {}).values()]}


@app.delete("/sources/{source_id}")
def delete_source(source_id: str) -> dict[str, Any]:
    source = source_payload(source_id)
    if not source:
        raise HTTPException(404, "Source not found")
    path = Path(source.get("path", ""))
    if path.exists():
        path.unlink(missing_ok=True)
    INDEX["sources"].pop(source_id, None)
    save_index()
    log_event("source_deleted", source.get("name", source_id))
    return {"ok": True}


@app.get("/sessions")
def list_sessions() -> dict[str, Any]:
    items = sorted(SESSIONS["sessions"].values(), key=lambda s: s.get("created", ""), reverse=True)
    return {"sessions": items}


@app.post("/sessions")
def create_session(req: SessionRequest) -> dict[str, Any]:
    sid = new_id()
    session = {"id": sid, "title": req.title.strip() or "New chat", "created": now_ts()}
    SESSIONS["sessions"][sid] = session
    save_sessions()
    log_event("session_created", session["title"])
    return session


@app.delete("/sessions/{session_id}")
def delete_session(session_id: str) -> dict[str, Any]:
    if session_id not in SESSIONS["sessions"]:
        raise HTTPException(404, "Session not found")
    SESSIONS["sessions"].pop(session_id, None)
    save_sessions()
    return {"ok": True}


@app.get("/notes")
def list_notes() -> dict[str, Any]:
    items = sorted(NOTES["notes"].values(), key=lambda n: n.get("updated", ""), reverse=True)
    return {"notes": items}


@app.post("/notes")
def create_note(req: NoteRequest) -> dict[str, Any]:
    nid = new_id()
    note = {"id": nid, "title": req.title.strip() or "Untitled note", "body": req.body, "updated": now_ts()}
    NOTES["notes"][nid] = note
    save_notes()
    log_event("note_created", note["title"])
    return note


@app.put("/notes/{note_id}")
def update_note(note_id: str, req: NoteRequest) -> dict[str, Any]:
    if note_id not in NOTES["notes"]:
        raise HTTPException(404, "Note not found")
    note = NOTES["notes"][note_id]
    note["title"] = req.title.strip() or note["title"]
    note["body"] = req.body
    note["updated"] = now_ts()
    save_notes()
    log_event("note_updated", note["title"])
    return note


@app.delete("/notes/{note_id}")
def delete_note(note_id: str) -> dict[str, Any]:
    if note_id not in NOTES["notes"]:
        raise HTTPException(404, "Note not found")
    NOTES["notes"].pop(note_id, None)
    save_notes()
    return {"ok": True}


@app.get("/audit")
def get_audit(limit: int = 50) -> dict[str, Any]:
    limit = max(1, min(limit, 500))
    return {"events": list(reversed(AUDIT["events"]))[:limit]}


@app.post("/ingest")
async def ingest(file: UploadFile = File(...)) -> dict[str, Any]:
    content = await file.read()
    if not content:
        raise HTTPException(400, "The uploaded file is empty.")
    max_bytes = int(os.getenv("MAX_UPLOAD_MB", "500")) * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(413, "File exceeds configured upload limit.")
    name = Path(file.filename or "uploaded-file").name
    sid = sid_for(name, content)
    suffix = Path(name).suffix.lower()
    path = SOURCES_DIR / f"{sid}{suffix}"
    path.write_bytes(content)
    try:
        chunks, meta = extract_file(path, suffix)
    except Exception as exc:
        chunks, meta = [], {"extraction": "failed", "error": str(exc)}
    source = {"id": sid, "name": name, "path": str(path), "type": suffix.lstrip("."), "size": len(content), "chunks": chunks, "meta": meta}
    INDEX["sources"][sid] = source
    save_index()
    log_event("source_ingested", f"{name} ({len(chunks)} chunks)")
    return {"source_id": sid, "name": name, "type": suffix.lstrip("."), "chunks": len(chunks), "meta": meta}


@app.post("/chat")
async def chat(req: ChatRequest) -> dict[str, Any]:
    if req.mode not in {"chapter", "general", "web"}:
        raise HTTPException(400, "Invalid mode")
    source = source_payload(req.source_id) if req.source_id else None
    if req.mode == "chapter":
        if not source:
            return {"answer": "প্রথমে একটি source upload/select করুন। Chapter Lock-এ source ছাড়া উত্তর দেওয়া হবে না।", "citations": []}
        evidence = retrieve(source, req.question)
        system = strict_prompt(source, evidence, req.question)
    elif req.mode == "web":
        evidence = []
        system = web_prompt()
    else:
        evidence = []
        system = general_prompt()
    answer = await chat_provider(system, req.question)
    citations = [{"page": c.get("page"), "text": c.get("text", "")[:220]} for c in evidence]
    log_event("chat", f"mode={req.mode} q_len={len(req.question)}")
    return {"answer": answer, "mode": req.mode, "source_id": req.source_id, "citations": citations}


@app.post("/generate")
async def generate(req: GenerateRequest) -> dict[str, Any]:
    kind = req.kind.lower().strip()
    if kind not in {"image", "audio", "music", "broadcast"}:
        raise HTTPException(400, "kind must be image, audio, music, or broadcast")
    if kind == "broadcast":
        return {"ok": True, "kind": kind, "message": "Broadcast script should be generated through /chat, then rendered by the selected TTS adapter."}
    prefix = "IMAGE" if kind == "image" else "AUDIO"
    url = os.getenv(f"{prefix}_API_URL", "").strip()
    if not url:
        return {"ok": False, "kind": kind, "message": f"{kind.title()} provider is not configured. Add {prefix}_API_URL and credentials in .env."}
    return {"ok": False, "kind": kind, "message": "Provider detected but its response format is provider-specific. Add the matching adapter under backend/providers."}


# ---------------------------------------------------------------------------
# Cloud voice (optional). Falls back to the phone's on-device TTS when this
# is not configured -- the app never fakes an audio result.
#
# Built-in adapter: Google Cloud Text-to-Speech, because it has good quality
# Neural2/Wavenet voices for both bn-IN (Bengali, India) and en-IN (Indian
# English), which is exactly the pairing this app needs. Get an API key from
# Google Cloud Console (enable the "Cloud Text-to-Speech API") and set
# GOOGLE_TTS_API_KEY in backend/.env. Nothing plays through the cloud voice
# until that key is set.
# ---------------------------------------------------------------------------

DEFAULT_VOICES = {
    "bn": {"languageCode": "bn-IN", "name": os.getenv("TTS_VOICE_BN", "bn-IN-Wavenet-A")},
    "en": {"languageCode": "en-IN", "name": os.getenv("TTS_VOICE_EN", "en-IN-Wavenet-D")},
}


@app.post("/tts")
async def text_to_speech(req: TtsRequest) -> Response:
    key = os.getenv("GOOGLE_TTS_API_KEY", "").strip()
    if not key:
        raise HTTPException(503, "Cloud voice is not configured. Set GOOGLE_TTS_API_KEY in backend/.env, or use the phone's built-in voice instead.")
    lang = "bn" if req.lang.lower().startswith("bn") else "en"
    voice = DEFAULT_VOICES[lang]
    payload = {
        "input": {"text": req.text},
        "voice": voice,
        "audioConfig": {"audioEncoding": "MP3", "speakingRate": float(os.getenv("TTS_SPEAKING_RATE", "0.95")), "pitch": 0.0},
    }
    url = f"https://texttospeech.googleapis.com/v1/text:synthesize?key={key}"
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(url, json=payload)
            r.raise_for_status()
            data = r.json()
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, f"Cloud voice provider error: {exc.response.text[:300]}") from exc
    except Exception as exc:
        raise HTTPException(502, f"Cloud voice request failed: {exc}") from exc
    audio_b64 = data.get("audioContent")
    if not audio_b64:
        raise HTTPException(502, "Cloud voice provider returned no audio.")
    audio_bytes = base64.b64decode(audio_b64)
    log_event("tts", f"lang={lang} chars={len(req.text)}")
    return Response(content=audio_bytes, media_type="audio/mpeg")
