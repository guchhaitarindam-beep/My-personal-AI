# V7 — কী পরিবর্তন হলো (V6 থেকে)

## 🦯 Accessibility — visually impaired teacher-এর জন্য

- **হাত-মুক্ত কথোপকথন মোড (Conversation Mode):** একবার বড় বাটনে চাপলে
  app নিজে থেকেই শোনা শুরু করে, প্রশ্ন শেষ হলে নিজে থেকেই জিজ্ঞাসা করে,
  উত্তর শোনানো শেষ হলে আবার নিজে থেকেই শুনতে শুরু করে। পুরো কথোপকথনে
  আর কোনো বাটনে চাপার দরকার নেই — শুধু কথা বলে যাওয়া যায়।
- **একটানা audio পড়া (Continuous reading):** আগে প্রতিটা বাক্যের পর
  ম্যানুয়ালি "Next" চাপতে হতো। এখন ডিফল্টভাবে পুরো উত্তর নিজে থেকেই
  বাক্যের পর বাক্য বলতে থাকে (চাইলে বন্ধ করা যায়)।
- **High-contrast mode:** কালো ব্যাকগ্রাউন্ড + উজ্জ্বল হলুদ লেখা —
  কম দৃষ্টিশক্তির জন্য সহজে পড়ার মতো contrast।
- **Adjustable text size (100%–200%)** পুরো app জুড়ে।
- **Spoken app-status announcements:** app চালু হলে, তা bengali voice-এ
  বলে দেয় backend সংযুক্ত আছে কিনা — স্ক্রিন দেখার দরকার নেই।
- **Haptic feedback:** মাইক্রোফোন চালু হলে ছোট vibration, যাতে বোঝা যায়
  app শুনতে প্রস্তুত।
- Tab পরিবর্তন হলে screen-reader-এর জন্য spoken announcement।

## 🎙️ আরো human-like ভয়েস

- **Cloud Voice (ঐচ্ছিক):** Backend-এ এখন `/tts` endpoint আছে যেটা
  Google Cloud Text-to-Speech-এর bn-IN/en-IN Wavenet voice ব্যবহার করে
  — ফোনের built-in TTS-এর চেয়ে অনেক বেশি স্বাভাবিক শোনায়। এটা
  configure করা না থাকলে app স্বয়ংক্রিয়ভাবে ফোনের নিজস্ব voice-এ ফিরে
  যায় — কিছুই ভাঙে না। চালু করতে `backend/.env`-এ
  `GOOGLE_TTS_API_KEY` বসান (Google Cloud Console থেকে, "Cloud
  Text-to-Speech API" enable করে)।

## 👩‍🏫 শিক্ষকদের জন্য নতুন Study action

- **Lesson Plan (Teacher):** নির্বাচিত source থেকে ৪৫ মিনিটের class
  lesson plan তৈরি করে (objective, activities, blackboard notes,
  assessment সহ)।
- **Oral Quiz Script (Teacher):** ক্লাসে মুখে মুখে জিজ্ঞাসা করার জন্য
  ১০টা প্রশ্নের script তৈরি করে।

## 📱 এখন ফোন দিয়েই APK build করা যায়

- `.github/workflows/build-apk.yml` — GitHub Actions cloud pipeline।
  ZIP আপলোড করে, "Run workflow" চাপলে GitHub-এর সার্ভারে build হয়,
  APK "Artifacts"-এ ডাউনলোডের জন্য থাকে। বিস্তারিত:
  `BUILD_FROM_PHONE_BN.md`।

## 🐛 গুরুত্বপূর্ণ বাগ ফিক্স

- **`flutter test` build-কে block করত:** `flutter create` স্বয়ংক্রিয়ভাবে
  একটা default test file বানায় যেটা `MyApp` নামের একটা class খোঁজে —
  কিন্তু আমাদের app-এর root widget-এর নাম `MyPersonalAI`। ফলে প্রতিবার
  নতুন project তৈরি করলে `flutter test` ব্যর্থ হতো এবং পুরো
  `BUILD_ANDROID_RELEASE.bat` script APK বানানোর আগেই থেমে যেত। এখন
  project তৈরির পরপরই আমাদের নিজের সঠিক test file বসিয়ে দেওয়া হয়।
- vibration ব্যবহারের জন্য manifest-এ `VIBRATE` permission যোগ করা
  হয়েছে (আগে না থাকায় কিছু ফোনে vibration silently fail করতে পারত)।
- ব্যবহার না হওয়া, ভাঙা duplicate script (`build_android_release.bat`,
  `create_flutter_project.bat`, `run_backend_windows.bat` — আগের V1-V3
  থেকে থেকে যাওয়া, ভুল ফাইলে copy করার bug ছিল) সরিয়ে ফেলা হয়েছে,
  যাতে ভুল script রান করে বিভ্রান্ত না হন।

## ❌ যা এখনও সম্ভব নয় (honestly)

- এই package থেকে সরাসরি compiled `.apk` পাঠানো এখনও সম্ভব নয় — GitHub
  Actions (উপরে) বা PC দিয়ে build করতে হবে।
- Human cloud voice চালু করতে হলে নিজের Google Cloud API key লাগবে
  (ফ্রি tier আছে, কিন্তু credential ছাড়া চলবে না)।
- Real image/music generation এখনও provider adapter-নির্ভর, fake করা
  হয়নি।
