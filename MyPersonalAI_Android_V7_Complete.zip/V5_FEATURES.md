# V5 Feature Map

### AI
- Chapter Lock / General / Web Agent modes
- Persistent sessions
- Voice-first question/answer flow
- Transparent backend/provider failures

### Study
- Summary
- Q&A
- MCQ
- Important questions
- Viva
- Revision sheet
- Audio lesson
- Evidence search

### Source intelligence
- Persistent SQLite source index
- Page-aware PDF extraction
- DOCX/TXT/MD/CSV/JSON parsing
- OCR hook
- Video audio extraction hook
- Evidence viewer

### Accessibility
- TalkBack semantic labels
- Large controls
- Bengali India / Indian English speech
- Sentence-level previous/next speech
- Stop speech
- Keyboard shortcut for desktop testing

### Personal workspace
- Notes
- Chat sessions
- Audit log
- Backend health/status

### Creative gateway
- Image brief
- Poster/banner brief
- Audio/music brief
- Broadcast script workflow
- Provider adapters intentionally separated from the Android UI

### Enterprise foundation
- API key isolation on backend
- Persistent database
- Audit events
- Request size limits
- CORS configuration
- Clear production security boundary
